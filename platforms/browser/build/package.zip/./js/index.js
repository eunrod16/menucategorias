$("#btn-play").on("click",function() {
  window.location = "categories.html";
});

$("#btn-help").on("click",function() {
  window.location = "help.html";
});
