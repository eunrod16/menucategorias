$("#btn-back").on("click",function() {
  window.location = "index.html";
});
